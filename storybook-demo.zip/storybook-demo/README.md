# Storebook Application

> Est. late 2023

----------------------------------------------------------------

## Requirements

NodeJS v19.9.0

### Developer Notes

Do not forget to switch to correct NodeJS version in case of using node version manager.

```bash
nvm use 19
```

----------------------------------------------------------------

## Running App

```bash
npm i
npm run storybook dev -p 6006
```

