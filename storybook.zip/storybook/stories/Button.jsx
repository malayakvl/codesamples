import React from 'react';
import PropTypes from 'prop-types';
import './button.css';

/**
 * Primary UI component for user interaction
 */
export const Button = ({ theme, primary, backgroundColor, borderRadius, size, label, labelCounter, labelIconBefore, labelIconAfter, ...props }) => {
  const mode = primary ? 'storybook-button--primary' : 'storybook-button--secondary';
  return (
    <button
      type="button"
      className={['storybook-button', `storybook-button--${size}`, theme, mode].join(' ')}
      {...props}
    >
      <div className="btn-content">
        {labelIconBefore && <span className={`icon icon-start ${labelIconBefore}`} />}
        <span>
          <span className="caption">{label}</span>
          {labelCounter && <em className="counter">{labelCounter ? labelCounter : ''}</em>}
        </span>
        {labelIconAfter && <span className={`icon icon-end ${labelIconAfter}`} />}
      </div>
      <style jsx>{`
        button {
          background-color: ${backgroundColor};
          border-radius: ${borderRadius};
        }
        //button > span {
        //  display: inline-block;
        //  margin-top: 2px;
        //}
        //button > span::before {
        //  content: "";
        //}
        em.counter {
          padding-left: 10px;
          opacity: 0.5;
          font-style: normal;
          font-weight: lighter;
        }
      `}</style>
    </button>
  );
};

Button.propTypes = {
  theme: PropTypes.oneOf(['blue-theme', 'white-theme']),
  /**
   * Is this the principal call to action on the page?
   */
  primary: PropTypes.bool,
  /**
   * What background color to use
   */
  backgroundColor: PropTypes.string,
  /**
   * How large should the button be?
   */
  size: PropTypes.oneOf(['extra-small', 'small', 'medium', 'large', 'extra-large']),
  /**
   * Button radius
   */
  borderRadius: PropTypes.string,
  /**
   * Button contents
   */
  label: PropTypes.string.isRequired,
  /**
   * Button counter
   */
  labelCounter: PropTypes.string,
  /**
   * Label icon before
   */
  labelIconBefore: PropTypes.string,
  /**
   * Lavel icon after
   */
  labelIconAfter: PropTypes.string,
  /**
   * Optional click handler
   */
  onClick: PropTypes.func,
};

Button.defaultProps = {
  theme: 'blue-theme',
  labelCounter: null,
  backgroundColor: '#5850EC',
  borderRadius: '2rem',
  primary: false,
  size: 'medium',
  onClick: undefined,
};
